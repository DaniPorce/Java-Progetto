package Classes;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 * Classe che definisce le caratteristiche di Prenotazione
 * @author Daniele Porcelli 20039368
 */
public class Prenotazione {
	/**
	 * LocalDate data
	 * LocalTime apertura
	 * LocalTime chiusura
	 * Docente docente
	 */
	private LocalDate data;
	private LocalTime apertura;
	private LocalTime chiusura;
	private Docente docente;
	/**
	 * Costruttore della classe Prenotazione
	 * @param LocalDate data
	 * @param LocalTime apertura
	 * @param LocalTime chiusura
	 * @param Docente docente
	 */
	public Prenotazione(LocalDate data, LocalTime apertura, LocalTime chiusura, Docente docente) {
		this.data = data;
		this.apertura = apertura;
		this.chiusura = chiusura;
		this.docente = docente;
	}
	/**
	 * Metodo che ritorna la data della prenotazione
	 * @return data
	 */
	public LocalDate getData() {
		return data;
	}
	/**
	 * Metodo che imposta la data della prenotazione
	 * @param data
	 */
	public void setData(LocalDate data) {
		this.data = data;
	}
	/**
	 * Metodo che ritorna l'orario di apertura della prenotazione
	 * @return apertura
	 */
	public LocalTime getApertura() {
		return apertura;
	}
	/**
	 * Metodo che imposta l'orario di apertura della prenotazione
	 * @param apertura
	 */
	public void setApertura(LocalTime apertura) {
		this.apertura = apertura;
	}
	/**
	 * Metodo che ritorna l'orario della chiusura della prenotazione
	 * @return chiusura
	 */
	public LocalTime getChiusura() {
		return chiusura;
	}
	/**
	 * Metodo che imposta l'orario della chiusura della prenotazione
	 * @param chiusura
	 */
	public void setChiusura(LocalTime chiusura) {
		this.chiusura = chiusura;
	}
	/**
	 * Metodo che ritorna il docente
	 * @return docente
	 */
	public Docente getDocente() {
		return docente;
	}
	/**
	 * Metodo che imposta il docente
	 * @param docente
	 */
	public void setDocente(Docente docente) {
		this.docente = docente;
	}
	//Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return "Prenotazione [data=" + data + ", apertura=" + apertura + ", chiusura=" + chiusura + ", docente="
				+ docente + "]";
	}
	
}
