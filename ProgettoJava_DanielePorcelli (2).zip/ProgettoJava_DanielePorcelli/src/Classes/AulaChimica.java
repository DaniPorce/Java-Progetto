package Classes;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import enumType.DotazioneAula;
import enumType.DotazioneChimica;
/**
 * Classe che definisce le caratteristiche di un'AulaChimica
 * @author Daniele Porcelli 20039368
 */
public class AulaChimica extends Aula {
	/**
	 * List<DotazioneChimica> dotazioniChimica
	 */
	List<DotazioneChimica> dotazioniChimica = new ArrayList<>();
	/**
	 * Costruttore della classe AulaChimica senza parametri
	 */
	public AulaChimica()
	{
		super();
	}
	/**
	 * Costruttore della classe AulaChimica
	 * @param String nome
	 * @param Integer capienza
	 * @param DotazioneChimica dotazione
	 */
	public AulaChimica(String nome, Integer capienza, DotazioneChimica dotazione) {
		super(nome, capienza);
		if(dotazioniChimica.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		this.dotazioniChimica.add(dotazione);
	}
	/**
	 * Costruttore della classe AulaChimica con lista di dotazioni 
	 * @param String nome
	 * @param Integer capienza
	 * @param List<DotazioneChimica> dotazioni
	 */
	public AulaChimica(String nome, Integer capienza, List<DotazioneChimica> dotazioni) {
		super(nome, capienza);
		this.dotazioniChimica.addAll(dotazioni);
	}
	/**
	 * Metodo che aggiunge una DotazioneAula
	 * @param dotazione
	 */
	public void aggiungiDotazione(DotazioneAula dotazione) {
		if(dotazioni.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioni.add(dotazione);
	}
	/**
	 * Metodo che aggiunge una DotazioneChimica
	 * @param dotazione
	 */
	public void aggiungiDotazioneChimica(DotazioneChimica dotazione) {
		if(dotazioniChimica.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioniChimica.add(dotazione);
	}
	/**
	 * Metodo che aggiunge una lista di dotazioni
	 * @param dotazioni
	 */
	public void aggiungiDotazioni(List<DotazioneAula> dotazioni) {
		this.dotazioni.addAll(dotazioni);
	}
	/**
	 * Metodo che aggiunge una lista di dotazioniChimica
	 * @param dotazioni
	 */
	public void aggiungiDotazioniChimica(List<DotazioneChimica> dotazioni) {
		this.dotazioniChimica.addAll(dotazioni);
	}
	/**
	 * Metodo che ritorna la lista di dotazioniChimica
	 * @return dotazioniChimica
	 */
	public List<DotazioneChimica> getDotazioniChimica() {
		return dotazioniChimica;
	}
	/**
	 * Metodo che imposta la lista di dotazioniChimica
	 * @param dotazioniChimica
	 */
	public void setDotazioniChimica(List<DotazioneChimica> dotazioniChimica) {
		this.dotazioniChimica = dotazioniChimica;
	}
	/**
	 * Metodo che permette di visualizzare se la dotazione � presente nella listaDotazioniChimica
	 * @param strumento
	 */
	public void visualizzaAulaDotazioneChimica(DotazioneChimica strumento){

		for(DotazioneChimica dot: this.getDotazioniChimica())
		{
			if(dot.equals(strumento))
				System.out.println(this.toString());
			else
				throw new NoSuchElementException("Non � presente nessuna aula con dotazione richiesta");
		}
	}
	//Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return " AulaChimica [dotazioniChimica=" + dotazioniChimica + super.toString();
	}

}