package Classes;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import enumType.DotazioneAula;
import enumType.DotazioneChimica;
import enumType.DotazioneInformatica;
/**
 * Classe che definisce le caratteristiche del Modello
 * @author Daniele Porcelli 20039368
 */
public class Modello {
	/**
	 * PropertyChangeSupport support
	 * ArrayList<Aula> aule
	 * ArrayList<Docente> docenti
	 * ListaAula lista
	 * HashSet<String> listaMatricole
	 */
	private PropertyChangeSupport support;
	private ArrayList<Aula> aule  = new ArrayList<>();
	private ArrayList<Docente> docenti = new ArrayList<>();
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		support.addPropertyChangeListener(listener);
	}
	private HashSet<String> listaMatricole = new HashSet<String>();
	/**
	 * Costruttore della classe Modello
	 */
	public Modello(){
		this.support = new PropertyChangeSupport(this);
	}
	/**
	 * Metodo che ritorna la lista di aule
	 * @return aule
	 */
	public ArrayList<Aula> getAule() {
		return this.aule;
	}
	/**
	 * Metodo che ritorna la lista di docenti
	 * @return docenti
	 */
	public ArrayList<Docente> getDocenti() {
		return this.docenti;
	}
	/**
	 * Metodo che ritorna la lista di matricole
	 * @return listaMatricole
	 */
	public HashSet<String> getMatricole() {
		return this.listaMatricole;
	}
	/* ************************ METODI AGGIUNTA/RIMOZIONE/RICERCA AULA/PRENOTAZIONE/DOCENTE ************************ */
	/**
	 * Metodo che permette di aggiungere un'aula con dotazioneAula
	 * @param nome
	 * @param capienza
	 * @param dotazione
	 */
	public void aggiungiAula(String nome,Integer capienza,DotazioneAula dotazione) {

		AulaSemplice a = new AulaSemplice();
		boolean trovato = false;
		for(Aula aula: aule)
		{
			if(aula.getNome().equals(nome) && aula.getCapienza().equals(capienza))
			{
				support.firePropertyChange("AulaSempliceGi�Presente",null,aula);
				trovato = true;
			}
		}
		if(!trovato)
		{
			a.setNome(nome);
			a.setCapienza(capienza);
			a.aggiungiDotazione(dotazione);
			aule.add(a);
			support.firePropertyChange("AulaSempliceAggiunta",null,a);
		}
	}
	/**
	 * Metodo che permette di aggiungere un'aula con DotazioneChimica
	 * @param nome
	 * @param capienza
	 * @param dotazione
	 */
	public void aggiungiAula(String nome,Integer capienza,DotazioneChimica dotazione) {

		AulaChimica a = new AulaChimica();
		boolean trovato = false;
		for(Aula aula: aule)
		{
			if(aula.getNome().equals(nome) && aula.getCapienza().equals(capienza))
			{
				support.firePropertyChange("AulaChimicaGi�Presente", null, aula);
				trovato = true;
			}
		}
		if(!trovato)
		{
			a.setNome(nome);
			a.setCapienza(capienza);
			a.aggiungiDotazioneChimica(dotazione);
			aule.add(a);
			support.firePropertyChange("AulaChimicaAggiunta",null,a);
		}
	}
	/**
	 * Metodo che permette di aggiungere un'aula con DotazioneInformatica
	 * @param nome
	 * @param capienza
	 * @param dotazione
	 */
	public void aggiungiAula(String nome,Integer capienza,DotazioneInformatica dotazione) {

		AulaInformatica a = new AulaInformatica();
		boolean trovato = false;
		for(Aula aula: aule)
		{
			if(aula.getNome().equals(nome) && aula.getCapienza().equals(capienza))
			{
				support.firePropertyChange("AulaInformaticaGi�Presente", null, aula);
				trovato = true;
			}
		}
		if(!trovato)
		{
			a.setNome(nome);
			a.setCapienza(capienza);
			a.aggiungiDotazioneInformatica(dotazione);
			aule.add(a);
			support.firePropertyChange("AulaInformaticaAggiunta",null,a);
		}
	}
	/**
	 * Metodo che permette di aggiungere un docente alla lista Docenti
	 * @param nome
	 * @param cognome
	 * @param matricola
	 */
	public void aggiungiDocente(String nome,String cognome,String matricola) {

		Docente docente = new Docente(nome,cognome,matricola);
		boolean trovato = false;
		for(Docente doc: docenti)
		{
			if(doc.getNome().equals(docente.getNome()) && doc.getCognome().equals(docente.getCognome()) && doc.getMatricola().equals(docente.getMatricola()))
			{
				support.firePropertyChange("DocenteGi�Presente",null,doc);
				trovato = true;
			}
		}
		if(!trovato)
		{
			docente.setNome(nome);
			docente.setCognome(cognome);
			if(listaMatricole.contains(matricola))
				throw new NoSuchElementException("Matricola gi� inserita");
			else
			{
				docente.setMatricola(matricola);
				listaMatricole.add(matricola);
			}
			docenti.add(docente);
			support.firePropertyChange("DocenteAggiunto",null,docente);
		}
	}
	/**
	 * Metodo che permette di cercare un'aula
	 * @param nome 
	 * @param capienza
	 * @return aula/null
	 */
	public Aula cercaAula(String nome_aula,Integer capienza)
	{
		for(Aula a : aule)
		{
			if(a.getNome().equals(nome_aula) && a.getCapienza().equals(capienza))
			{
				support.firePropertyChange("AulaTrovata",null,a);
				return a;
			}
		}
		if(this.aule.isEmpty())
			support.firePropertyChange("AulaNonTrovata",null,null);
		return null;
	}
	/**
	 * Metodo che permette di cercare un docente dalla lista docenti
	 * @param nome
	 * @param cognome
	 * @param matricola
	 * @return docente/null
	 */
	public Docente cercaDocente(String nome,String cognome,String matricola){

		if(this.docenti.isEmpty())
		{
			support.firePropertyChange("ListaDocentiVuota",null,null);
			return null;
		}

		for(Docente doc: docenti)
		{
			if(doc.getNome().equals(nome) && doc.getCognome().equals(cognome) && doc.getMatricola().equals(matricola))
			{
				support.firePropertyChange("DocenteTrovato",null,doc);
				return doc;
			}
			else
				support.firePropertyChange("DocenteNonTrovato",null,null);
		}


		return null;
	}
	/**
	 * Metodo che permette di cercare una Prenotazione dalla lista AulePrenotate
	 * @param data
	 * @param apertura
	 * @param chiusura
	 * @param matricola
	 * @return prenotazione/null
	 */
	public Prenotazione cercaPrenotazione(LocalDate data,LocalTime apertura,LocalTime chiusura,Docente docente)
	{
		Prenotazione p = new Prenotazione(data,apertura,chiusura,docente);
		for(Aula aula : aule)
		{
			for(Prenotazione pr: aula.getPrenotazioni())
			{
				if(pr.getData().equals(p.getData()) && pr.getApertura().equals(p.getApertura()) && pr.getChiusura().equals(p.getChiusura()) && pr.getDocente().equals(docente))
				{
					support.firePropertyChange("PrenotazioneTrovata",null,pr);
					return p;
				}
			}

		}
		return null;
	}
	/**
	 * Metodo che permette di eliminare un'aula
	 * @param nome_aula
	 */
	public boolean eliminaAula(String nome_aula) {

		Aula a = null;
		for(Aula aula: aule)
		{
			if(aula.getNome().equals(nome_aula))
				a = aula;
		}
		if(a != null)
		{
			aule.remove(a);
			support.firePropertyChange("AulaEliminata",null,a);
			return true;
		}
		else
		{
			support.firePropertyChange("AulaNonEliminata",null,null);
			return false;
		}
	}
	/**
	 * Metodo che permette di eliminare un docente dalla lista docenti
	 * @param nome
	 * @param cognome
	 * @param matricola
	 * @return boolean
	 */
	public boolean eliminaDocente(String nome,String cognome,String matricola) {

		boolean ok = false;
		Docente doc = null;
		try {
			doc = this.cercaDocente(nome,cognome,matricola);
			if (doc.getNome() == null || doc.getCognome() == null || doc.getMatricola() == null)
			{
				throw new NullPointerException();
			}
			else
			{
				docenti.remove(doc);
				this.listaMatricole.remove(matricola);
				ok = true;
				support.firePropertyChange("DocenteEliminato",matricola,doc);
			}
		}
		catch(NullPointerException e)
		{
			support.firePropertyChange("DocenteNonEliminato",null,null);
		}
		return ok;
	}
	/**
	 * Metodo che permette di eliminare una prenotazione dalla lista AulePrenotate
	 * @param nome_aula
	 * @param data
	 * @param apertura
	 * @param chiusura
	 * @return boolean
	 */
	public boolean eliminaPrenotazione(String nome_aula,LocalDate data,LocalTime apertura,LocalTime chiusura,Docente docente)
	{
		if(this.aule.isEmpty())
			support.firePropertyChange("ListaPrenotazioneVuota",null,null);

		for(Aula a: aule)
		{
			if(a.getNome().equals(nome_aula))
			{
				for(Prenotazione p: a.getPrenotazioni())
				{
					if(p.getData().equals(data) && p.getApertura().equals(apertura) && p.getChiusura().equals(chiusura) && p.getDocente().equals(docente))
					{
						a.getPrenotazioni().remove(p);
						support.firePropertyChange("PrenotazioneEliminata",null,p);
						return true;
					}
				}
			}
			else
				System.out.println("La prenotazione non � stata trovata");
		}
		return false;
	}
	/**
	 * Metodo che permette di prenotare un'aula
	 * @param nome_aula
	 * @param data
	 * @param apertura
	 * @param chiusura
	 * @param matricola
	 */
	public void PrenotaAula(String nome_aula,LocalDate data,LocalTime apertura,LocalTime chiusura,Docente docente)
	{
		Prenotazione p = new Prenotazione(data,apertura,chiusura,docente);
		boolean trovato = false;

		if(this.docenti.isEmpty())
			support.firePropertyChange("PrenotazioneNonAggiunta",null,null);

		for(Aula a: aule)
		{
			if(a.getNome().equals(nome_aula))
			{
				for(Prenotazione pr: a.getPrenotazioni())
				{
					if(pr.getData().equals(data) && pr.getApertura().equals(apertura) && pr.getChiusura().equals(chiusura) && pr.getDocente().equals(docente))
					{
						support.firePropertyChange("PrenotazioneGi�Presente", null, pr);
						trovato = true;
					}
				}
			}
		}
		if(!trovato && !this.docenti.isEmpty() && this.docenti.contains(docente))
		{
			for(Aula a : aule) {

				if(a.getNome().equals(nome_aula))
				{
					for(Prenotazione pr: a.getPrenotazioni())
					{
						if(pr.getData().equals(p.getData()))
						{
							if(p.getApertura().getHour() < pr.getApertura().getHour() && p.getChiusura().getHour() < pr.getApertura().getHour() || p.getApertura().getHour() > pr.getChiusura().getHour() && p.getChiusura().getHour() > pr.getChiusura().getHour())
							{
								a.getPrenotazioni().add(p);
								support.firePropertyChange("PrenotazioneAggiunta",null,p);	
								break;
							}
							else
							{
								support.firePropertyChange("PrenotazioneNonAggiunta",null,null);
								break;
							}
						}
						else
						{
							a.getPrenotazioni().add(p);
							support.firePropertyChange("PrenotazioneAggiunta", null, p);
							break;
						}
					}
					if(a.getPrenotazioni().isEmpty())
					{
						a.getPrenotazioni().add(p);
						support.firePropertyChange("PrenotazioneAggiunta", null, p);
						break;
					}
				}
			}
		}
	}
	/**
	 * Metodo che permette di stampare ReportAula
	 * @param aula
	 * @param nome_aula
	 * @param data
	 */
	public void stampaReportAula(Aula aula, String nome_aula,LocalDate data) {

		if(this.aule.isEmpty() || this.docenti.isEmpty() || !this.aule.contains(aula) || nome_aula == null || data == null)
			this.listaAuleVuota();
		else 
		{
			Aula.Report report = aula.new Report(aule);
			report.creaReportAula(nome_aula, data);
			support.firePropertyChange("ReportAulaStampato",null,report.getReport()); 
		}

	}
	/**
	 * Metodo che permette di stampare ReportDocente
	 * @param aula
	 * @param data
	 * @param docente
	 */
	public void stampaReportDocente(Aula aula,LocalDate data, Docente docente) {

		if(this.aule.isEmpty() || this.docenti.isEmpty() || !this.aule.contains(aula) || data == null || docente == null)
			this.listaAuleVuota();
		else
		{
			Aula.Report report = aula.new Report(aule);
			report.creaReportDocente(data, docente);
			support.firePropertyChange("ReportDocenteStampato",null,report.getReport());
		}

	}
	/* ************************ METODI FILE ************************ */
	/** Metodo per caricare sul file aule.txt tutte le aule
	 * @param fileName nome del file 
	 */
	public void caricaSuFileAule(File filename)
	{
		try {
			FileWriter writer = new FileWriter(filename);
			for(Aula a: this.getAule()) {
				writer.write("Dati aula: " + a.toString() + "\n");
			}
			writer.close();
		}
		catch(IOException e) {
			support.firePropertyChange("ErroreCaricamentoAulesuFile",filename,null);
		}
		support.firePropertyChange("caricamentoAuleSuFileCorretto",null,filename);
	}
	/**
	 * Metodo per caricare sul file prenotazioni.txt tutte le prenotazioni
	 * @param filename nome del file  
	 * @param nome_aula
	 */
	public void caricaSuFilePrenotazioni(File filename , String nome_aula)
	{
		try {
			FileWriter writer = new FileWriter(filename);
			for(Aula a : aule)
			{
				if(a.getNome().equals(nome_aula))
				{
					for(Prenotazione p: a.getPrenotazioni()) {
						writer.write("Dati prenotazione: " + p.toString() + "\n");
					}
				}
			}
			writer.close();
		}
		catch(IOException e) {
			support.firePropertyChange("ErroreCaricamentoPrenotazionisuFile",filename,null);
		}
		support.firePropertyChange("caricamentoPrenotazioniSuFileCorretto",null,filename);
	}
	/**
	 *  Metodo per caricare sul file ReportDocente.txt tutti report
	 * @param filename
	 * @param data
	 * @param d
	 * @param a
	 */
	public void caricaSuFileReportDocente(File filename,LocalDate data,Docente d,Aula aula)
	{
		try {
			FileWriter writer = new FileWriter(filename);
			Aula.Report report = aula.new Report(aule);
			report.creaReportDocente(data, d);
			List<Prenotazione> lista = report.getReport();
			for(Prenotazione p: lista)
				writer.write("Dati ReportDocente: " + p.toString() + "\n");

			writer.close();
		}
		catch(IOException e) {
			support.firePropertyChange("ErroreCaricamentoReportDocentesuFile",filename,null);
		}
		support.firePropertyChange("caricamentoReportDocenteCorretto",null,filename);
	}
	/**
	 * Metodo per caricare sul file ReportAula.txt tutti report
	 * @param filename
	 * @param data
	 * @param nome_aula
	 * @param aula
	 */
	public void caricaSuFileReportAula(File filename,LocalDate data,String nome_aula,Aula aula)
	{
		try {
			FileWriter writer = new FileWriter(filename);
			Aula.Report report = aula.new Report(aule);
			report.creaReportAula(nome_aula, data);
			List<Prenotazione> lista = report.getReport();
			for(Prenotazione p: lista)
				writer.write("Dati ReportAula: " + p.toString() + "\n");

			writer.close();
		}
		catch(IOException e) {
			support.firePropertyChange("ErroreCaricamentoReportAulasuFile",filename,null);
		}
		support.firePropertyChange("caricamentoReportAulaCorretto",null,filename);
	}
	/**
	 * Metodo per caricare su file docenti.txt tutti i docenti
	 * @param filename
	 */
	public void caricaSuFileDocenti(File filename)
	{
		try {
			FileWriter writer = new FileWriter(filename);
			for(Docente d: this.getDocenti()) {
				writer.write("Dati docente: " + d.toString() + "\n");
			}
			writer.close();
		}
		catch(IOException e) {
			support.firePropertyChange("ErroreCaricamentoDocentisuFile",filename,null);
		}
		support.firePropertyChange("caricamentoDocentiSuFileCorretto",null,filename);
	}
	/**
	 * Metodo che permette di caricare da file prenotazioni.txt le informazioni riguardanti le prenotazioni
	 * @param filename
	 * @throws IOException
	 */
	public void caricaDaFilePrenotazioni(String filename) throws IOException
	{

		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			System.out.println(everything);
		} finally {
			br.close();
		}
	}
	/**
	 * Metodo che permette di caricare da file aule.txt le informazioni riguardanti le aule
	 * @param filename
	 * @throws IOException
	 */
	public void caricaDaFileAule(String filename) throws IOException
	{

		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			System.out.println(everything);
		} finally {
			br.close();
		}
	}
	/**
	 * Metodo che permette di caricare da file docenti.txt le informazioni riguardanti i docenti
	 * @param filename
	 * @throws IOException
	 */
	public void caricaDaFileDocenti(String filename) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			System.out.println(everything);
		} finally {
			br.close();
		}

	}
	/**
	 * Metodo che permette di caricare da file ReportAula.txt le informazioni riguardanti reportAula
	 * @param filename
	 * @throws IOException
	 */
	public void caricaDaFileReportAula(String filename) throws IOException
	{

		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			System.out.println(everything);
		} finally {
			br.close();
		}
	}
	/**
	 * Metodo che permette di caricare da file ReportDocente.txt le informazioni riguardanti reportDocente
	 * @param filename
	 * @throws IOException
	 */
	public void caricaDaFileReportDocente(String filename) throws IOException
	{

		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			System.out.println(everything);
		} finally {
			br.close();
		}
	}
	/* ********************************* CONTROLLI ********************************* */

	/**
	 * Metodo che permette il controllo del range tipo dell'aula
	 * @param val
	 * @return valore / TipoNonValido
	 */
	public int checkRangeTipoAula(int val)
	{
		try {
			if(val < 0 || val > 2)
				throw new NoSuchElementException();
		}
		catch(NoSuchElementException e)
		{
			support.firePropertyChange("TipoNonValido",null,null);
		}
		return val;
	}

	/**
	 * Metodo che stampa la stringa ListaAuleVuota
	 */
	public void listaAuleVuota()
	{
		support.firePropertyChange("ListaAuleVuota",null,null);
	}

	/**
	 * Metodo che stampa la stringa ListaDocentiVuota
	 */
	public void listaDocentiVuota()
	{
		support.firePropertyChange("ListaDocentiVuota",null,null);
	}

	/**
	 * Metodo che stampa la stringa ListaPrenotazioneVuota
	 */
	public void listaPrenotazioneVuota()
	{
		support.firePropertyChange("ListaPrenotazioneVuota",null,null);
	}

	/**
	 * Metodo che stampa la stringa DocenteNonEliminato
	 */
	public void DocenteNonEliminato ()
	{
		support.firePropertyChange("DocenteNonEliminato",null,null);
	}

}




