package Classes;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import enumType.DotazioneAula;
import enumType.DotazioneChimica;

/**
 * Classe che definisce le caratteristiche per verificare il Modello
 * @author Daniele Porcelli 20039368
 */
class TestModello {

	Modello modello;
	ArrayList<Aula> aule;
	ArrayList<Docente> docenti;
	AulaSemplice a1;
	AulaChimica a2;
	AulaInformatica a3;
	Docente d1,d2;
	Prenotazione pr1;

	/**
	 * Metodo di inizializzazione test con gli oggetti
	 */
	@BeforeEach
	public void init() {

		modello = new Modello();
		aule = new ArrayList<>();
		docenti = new ArrayList<>();
		a1 = new AulaSemplice("a1", 100, DotazioneAula.Lim);
		a2 = new AulaChimica("a2", 200, DotazioneChimica.Laboratorio);
		d1 = new Docente("Daniele","Porcelli","20039368");
		d2 = new Docente("Luca","Piovesan","20035367");
		pr1 = new Prenotazione(LocalDate.of(2001, 3, 3),LocalTime.of(7, 0),LocalTime.of(12, 0),d1);
		a1.Prenota(pr1);
		aule.add(a1);
		aule.add(a2);
		docenti.add(d1);
		docenti.add(d2);
		modello.aggiungiAula("a1", 100, DotazioneAula.Lim);
		modello.aggiungiAula("a2", 200, DotazioneChimica.Laboratorio);
		modello.aggiungiDocente("Daniele", "Porcelli", "20039368");
		modello.aggiungiDocente("Luca", "Piovesan", "20035367");
		modello.PrenotaAula("a1", LocalDate.of(2001, 3, 3), LocalTime.of(7, 0), LocalTime.of(12, 0),d1);
		
	}

	/**
	 * Metodo per verifica correttezza metodo aggiungiAula
	 */

	@Test public void aggiungiAula() {
		Assertions.assertEquals(aule.size(),modello.getAule().size());
		int i = 0;
		for (Aula aula: aule)
		{
			Assertions.assertEquals(aula.getNome(),modello.getAule().get(i).getNome());
			Assertions.assertEquals(aula.getCapienza(),modello.getAule().get(i).getCapienza());
			Assertions.assertEquals(aula.getDotazioni(),modello.getAule().get(i).getDotazioni());
			i++;
		}
	}
	
	/**
	 * Metodo per verifica correttezza metodo aggiungiDocente
	 */

	@Test public void aggiungiDocente() {
		Assertions.assertEquals(docenti.size(),modello.getDocenti().size());
		int i = 0;
		for (Docente docente : docenti)
		{
			Assertions.assertEquals(docente.getNome(), modello.getDocenti().get(i).getNome());
			Assertions.assertEquals(docente.getCognome(), modello.getDocenti().get(i).getCognome());
			Assertions.assertEquals(docente.getMatricola(), modello.getDocenti().get(i).getMatricola());
			i++;
		}
	}

	/**
	 * Metodo che verifica correttezza metodo cercaAula
	 */
	
	@Test public void cercaAula() {
		
		Aula aFound = this.modello.cercaAula("a1", 100);
		Assertions.assertEquals(aFound.getNome(),a1.getNome());
		Assertions.assertEquals(aFound.getCapienza(),a1.getCapienza());
		Assertions.assertEquals(aFound.getDotazioni(),a1.getDotazioni());
		Aula aNotFound = this.modello.cercaAula("a3", 300);
		Assertions.assertEquals(aNotFound, null);

	}
	
	/**
	 * Metodo che verifica la correttezza del metodo cercaDocente
	 */
	
	@Test public void cercaDocente() {
		Docente dFound = this.modello.cercaDocente("Daniele", "Porcelli", "20039368");
		Assertions.assertEquals(dFound.getNome(),d1.getNome());
		Assertions.assertEquals(dFound.getCognome(),d1.getCognome());
		Assertions.assertEquals(dFound.getMatricola(),d1.getMatricola());
		Docente dNotFound = this.modello.cercaDocente("Nicola", "Maraschi", "20041044");
		Assertions.assertEquals(dNotFound, null);
	}
	
	/**
	 * Metodo che verifica la correttezza del metodo cercaPrenotazione
	 */
	@Test public void cercaPrenotazione(){
		Prenotazione pFound = this.modello.cercaPrenotazione(LocalDate.of(2001, 3, 3), LocalTime.of(7, 0), LocalTime.of(12,0), d1);
		Assertions.assertEquals(pFound.getData(), pr1.getData());
		Assertions.assertEquals(pFound.getApertura(), pr1.getApertura());
		Assertions.assertEquals(pFound.getChiusura(), pr1.getChiusura());
		Assertions.assertEquals(pFound.getDocente(), pr1.getDocente());
	}
	
	/**
	 * Metodo che verifica la correttezza del metodo eliminaAula
	 */
	@Test public void eliminaAula() {
		
		aule.remove(a2);
		@SuppressWarnings("unused")
		boolean delete = this.modello.eliminaAula("a2");
		Assertions.assertEquals(aule.size(), this.modello.getAule().size());
		int i = 0;
		for(Aula aula : aule)
		{
			Assertions.assertEquals(aula.getNome(),this.modello.getAule().get(i).getNome());
			Assertions.assertEquals(aula.getCapienza(),this.modello.getAule().get(i).getCapienza());
			Assertions.assertEquals(aula.getDotazioni(),this.modello.getAule().get(i).getDotazioni());
			i++;
		}
		delete = this.modello.eliminaAula("a4");
		Assertions.assertFalse(aule.size() != this.modello.getAule().size());
	}
	
	/**
	 * Metodo che verifica la correttezza del metodo eliminaDocente
	 */
	@Test public void eliminaDocente()
	{
		boolean delete = this.modello.eliminaDocente("Daniele", "Porcelli", "20039368");
		Assertions.assertTrue(delete);
	}
	
	/**
	 * Metodo che verifica la correttezza del metodo stampaReportAula
	 */
	
	@Test public void stampaReportAula()
	{
		Aula.Report report = a1.new Report(aule);
		report.creaReportAula("a1", LocalDate.of(2001, 3, 3));
		Assertions.assertEquals(modello.getAule().get(0).getDotazioni().size(), 3);
		Assertions.assertEquals(modello.getAule().get(1).getPrenotazioni().size(), 0);
	}
	
	/**
	 * Metodo che verifica la correttezza del metodo stampaReportDocente
	 */
	@Test public void stampaReportDocente()
	{
		Aula.Report report = a1.new Report(aule);
		report.creaReportDocente(LocalDate.of(2001, 3, 3), d1);
		Assertions.assertEquals(modello.getAule().get(0).getDotazioni().size(), 3);
		Assertions.assertEquals(modello.getAule().get(1).getPrenotazioni().size(), 0);
	}
	
	
	
}
