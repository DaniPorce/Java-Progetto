package Classes;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.NoSuchElementException;
import java.util.Scanner;

import enumType.DotazioneAula;
import enumType.DotazioneChimica;
import enumType.DotazioneInformatica;
/**
 * Classe che definisce le caratteristiche del Controller
 * @author Daniele Porcelli 20039368
 */
public class Controller {
	/**
	 * Vista vista
	 * Modello modello
	 * Scanner sc
	 */
	private Vista vista;
	private Modello modello;
	private Scanner sc = new Scanner(System.in);
	/**
	 * Costruttore del Controller
	 * @param Vista v
	 * @param Modello m
	 */
	public Controller(Vista v,Modello m)
	{
		this.vista = v;
		this.modello = m;
	}
	public void avvioCartella()
	{
		this.vista.startingApp();
		File f1 = new File("aule.txt");
		File f2 = new File("prenotazioni.txt");
		File f3 = new File("docenti.txt");
		boolean runningApp = true;
		while(runningApp) {
			int response = vista.displayMenu();
			switch(response)
			{
			case 0:
				String nome = this.inserireNomeAula();
				System.out.println("Nome Aula: " + nome);
				int cap = this.inserireCapienzaAula();
				System.out.println("Capienza: " + cap);
				int val = this.inserireTipoAula();
				switch(val)
				{
				case 0:
					DotazioneAula dot = this.inserireDotazioneSemplice();
					System.out.println("Dotazione scelta: " + dot);
					this.modello.aggiungiAula(nome, cap, dot);
					this.modello.caricaSuFileAule(f1);
					break;
				case 1:
					DotazioneChimica d1 = this.inserireDotazioneChimica();
					System.out.println("Dotazione scelta: " + d1);
					this.modello.aggiungiAula(nome, cap, d1);
					this.modello.caricaSuFileAule(f1);
					break;
				case 2:
					DotazioneInformatica d2 = this.inserireDotazioneInformatica();
					System.out.println("Dotazione scelta: " + d2);
					this.modello.aggiungiAula(nome, cap, d2);
					this.modello.caricaSuFileAule(f1);
					break;
				}
				break;
			case 1:
				String nome_docente = this.inserireNomeDocente();
				System.out.println("Nome docente scelto: " + nome_docente);
				String cognome_docente = this.inserireCognomeDocente();
				System.out.println("Cognome docente scelto: " + cognome_docente);
				String matricola = this.inserireMatricola();
				System.out.println("Matricola docente: " + matricola);
				this.modello.aggiungiDocente(nome_docente, cognome_docente, matricola);
				this.modello.caricaSuFileDocenti(f3);
				break;
			case 2:
				String n = this.inserireNomeAula();
				LocalDate data = this.inserisciPrenotazione();
				LocalTime ap = this.inserisciApertura();
				LocalTime ch = this.inserisciChiusura();
				Docente doc = this.inserisciDocente();
				this.modello.PrenotaAula(n, data, ap, ch, doc);
				if(this.modello.getDocenti().size() != 0 && this.modello.getDocenti().contains(doc))
					this.modello.caricaSuFilePrenotazioni(f2, n);
				else
					this.modello.listaPrenotazioneVuota();
				break;
			case 3:
				String n1 = this.inserireNomeAula();
				int c1 = this.inserireCapienzaAula();
				if(this.modello.cercaAula(n1,c1) == null)
					System.out.println("Aula non trovata");
				break;
			case 4:
				String n2 = this.inserireNomeDocente();
				String cognome = this.inserireCognomeDocente();
				String mat = this.inserireMatricola();
				this.modello.cercaDocente(n2, cognome, mat);
				break;
			case 5:
				String n4 = this.inserireNomeAula();
				this.modello.eliminaAula(n4);
				break;
			case 6:
				String n3 = this.inserireNomeDocente();
				String x = this.inserireCognomeDocente();
				String mt = this.inserireMatricola();
				this.modello.eliminaDocente(n3, x, mt);
				break;
			case 7:
				String n5 = this.inserireNomeAula();
				LocalDate data1 = this.inserisciPrenotazione();
				LocalTime apertura = this.inserisciApertura();
				LocalTime chiusura = this.inserisciChiusura();
				Docente docente = this.inserisciDocente();
				this.modello.eliminaPrenotazione(n5, data1, apertura, chiusura, docente);
				break;
			case 8:
				this.visualizzaPrenotazioni();
				break;
			case 9:
				this.visualizzaAule();
				break;
			case 10:
				this.visualizzaDocenti();
				break;
			case 11:
				String parola = this.inserireNomeAula();
				int cp = this.inserireCapienzaAula();
				LocalDate date = this.inserisciPrenotazione();
				this.modello.stampaReportAula(this.modello.cercaAula(parola,cp),parola,date);
				break;
			case 12:
				String par = this.inserireNomeAula();
				int capie = this.inserireCapienzaAula();
				LocalDate ldate = this.inserisciPrenotazione();
				Docente dc = this.inserisciDocente();
				this.modello.stampaReportDocente(this.modello.cercaAula(par, capie), ldate,dc);
				break;
			case 13:
				this.vista.closeApp();
				this.sc.close();
				runningApp = false;
				break;
			}
		}

	}

	/**
	 * Metodo per permettere di inserire il nome aula
	 * @return nome
	 */
	private String inserireNomeAula() {
		String nome;
		try {
			System.out.println("Inserire nome aula: ");
			nome = this.sc.next();
		}
		catch(NoSuchElementException e) {
			nome = null;
		}
		return nome;
	}

	/**
	 * Metodo che permette di inserire la capienza aula
	 * @return capienza
	 */
	private int inserireCapienzaAula() {
		int capienza;
		try {
			System.out.println("Inserire capienza aula: ");
			capienza = this.sc.nextInt();
		}
		catch(NoSuchElementException e) {
			capienza = 0;
		}
		return capienza;
	}

	/**
	 * Metodo che permette di inserire il tipo aula
	 * @return val
	 */
	private int inserireTipoAula() {
		int val = 0;
		try {
			System.out.println("Quale tipo di aula scegli: ");
			System.out.println("Semplice: 0\nChimica: 1\nInformatica: 2");
			val = this.sc.nextInt();
			if(val < 0 || val > 2)
				throw new NoSuchElementException();
		}
		catch(NoSuchElementException e)
		{
			this.modello.checkRangeTipoAula(val);
		}
		return val;
	}

	/**
	 * Metodo che stampa tutte le dotazioni AulaSemplice
	 */
	private void dotazioneDisponibili() {

		System.out.println("Dotazioni disponibili AulaSemplice: ");
		for(DotazioneAula d: DotazioneAula.values())
			System.out.println(d.ordinal() + ": " + d);
	}

	/**
	 * Metodo che stampa tutte le dotazioni AulaChimica
	 */
	private void dotazioniChimica() {

		System.out.println("Dotazioni disponibili AulaChimica: ");
		for(DotazioneChimica d: DotazioneChimica.values())
			System.out.println(d.ordinal() + ": " + d);
	}

	/**
	 * Metodo che stampa tutte le dotazioni AulaInformatica
	 */
	private void dotazioniInformatica() {

		System.out.println("Dotazioni disponibili AulaInformatica: ");
		for(DotazioneInformatica d: DotazioneInformatica.values())
			System.out.println(d.ordinal() + ": " + d);
	}

	/**
	 * Metodo che permette di inserire una dotazioneSemplice
	 * @return DotazioneAula d1
	 */
	private DotazioneAula inserireDotazioneSemplice() {
		int num;
		DotazioneAula d1 = null;
		try {
			this.dotazioneDisponibili();
			System.out.println("Scegliere una dotazione: ");
			num = this.sc.nextInt();
			for(DotazioneAula d : DotazioneAula.values())
			{
				if(d.ordinal() == num)
				{
					d1 = d;
					break;
				}
			}
		}
		catch(NoSuchElementException e) {
			num = 0;
		}
		return d1;
	}

	/**
	 * Metodo che permette di inserire una dotazioneChimica
	 * @return DotazioneChimica d2
	 */
	private DotazioneChimica inserireDotazioneChimica() {
		int num;
		DotazioneChimica d2 = null;
		try {
			this.dotazioniChimica();
			System.out.println("Scegliere una dotazione: ");
			num = this.sc.nextInt();
			for(DotazioneChimica d : DotazioneChimica.values())
			{
				if(d.ordinal() == num)
				{
					d2 = d;
					break;
				}
			}
		}
		catch(NoSuchElementException e) {
			num = 0;
		}
		return d2;
	}

	/**
	 * Metodo che permette di inserire una dotazioneInformatica
	 * @return DotazioneInformatica d3
	 */
	private DotazioneInformatica inserireDotazioneInformatica() {
		int num;
		DotazioneInformatica d3 = null;
		try {
			this.dotazioniInformatica();
			System.out.println("Scegliere una dotazione: ");
			num = this.sc.nextInt();
			for(DotazioneInformatica d : DotazioneInformatica.values())
			{
				if(d.ordinal() == num)
				{
					d3 = d;
					break;
				}
			}
		}
		catch(NoSuchElementException e) {
			num = 0;
		}
		return d3;
	}

	/**
	 * Metodo che permette di inserire il nome del Docente
	 * @return nome
	 */
	private String inserireNomeDocente() {
		String nome;
		try {
			System.out.println("Inserisci nome docente: ");
			nome = this.sc.next();
		}
		catch(NoSuchElementException e) {
			nome = null;
		}
		return nome;
	}

	/**
	 * Metodo che permette di inserire il cognome del Docente
	 * @return cognome
	 */
	private String inserireCognomeDocente() {
		String cognome;
		try {
			System.out.println("Inserisci cognome docente: ");
			cognome = this.sc.next();
		}
		catch(NoSuchElementException e) {
			cognome = null;
		}
		return cognome;
	}

	/**
	 * Metodo che permette di inserire una matricola per Docente
	 * @return matricola
	 */
	private String inserireMatricola() {
		String matricola = null;
		boolean flag = false;
		while(!flag)
		{
			try {
				System.out.println("Inserisci matricola docente: ");
				matricola = this.sc.next();
				if ( matricola.length() != 8)
					throw new NoSuchElementException();
				else
					flag = true;
			}
			catch(NoSuchElementException e) {
				System.out.println("Matricola non valida");
			}
		}
		return matricola;
	}

	/**
	 * Metodo che permette la visualizzazione della lista Aule
	 */
	private void visualizzaAule() {
		if(this.modello.getAule().isEmpty())
			this.modello.listaAuleVuota();
		else
		{
			for(Aula aula: this.modello.getAule())
				System.out.println(aula.toString());
		}
	}

	/**
	 * Metodo che permette la visualizzazione della lista Prenotazioni
	 */
	private void visualizzaPrenotazioni() {

		if(this.modello.getAule().isEmpty())
			this.modello.listaPrenotazioneVuota();
		else
		{
			if(this.modello.getAule().get(0).getPrenotazioni().isEmpty())
				this.modello.listaPrenotazioneVuota();
		}
		for(Aula aula: this.modello.getAule())
		{
			for(Prenotazione p: aula.getPrenotazioni())
				System.out.println(p.toString());
		}
	}

	/**
	 * Metodo che permette l'inserimento di anno,mese,giorno per il giorno della prenotazione
	 * @return LocalDate(anno,mese,giorno)
	 */
	private LocalDate inserisciPrenotazione() {
		int anno = 0;
		int mese = 0;
		int giorno = 0;
		boolean ok = false;
		while(!ok)
		{
			try {

				System.out.println("Inserisci anno: ");
				anno = this.sc.nextInt();
				System.out.println("Inserisci mese: ");
				mese = this.sc.nextInt();
				System.out.println("Inserisci giorno: ");
				giorno = this.sc.nextInt();
				if(anno > 0 && mese >=1 && mese <= 12 && giorno >= 1 && giorno <= 31)
					ok = true;
				else
					throw new NoSuchElementException();

			}
			catch(NoSuchElementException e) {
				System.out.println("Formato non valido");
			}
		}
		return LocalDate.of(anno, mese, giorno);
	}

	/**
	 * Metodo che permette l'inserimento dell'orario di apertura per la prenotazione
	 * @return LocalTime(ora,minuto)
	 */
	private LocalTime inserisciApertura() {
		int ora = 0;
		int minuto = 0;
		boolean ok = false;
		while(!ok)
		{
			try {
				System.out.println("Inserisci ora apertura: ");
				ora = this.sc.nextInt();
				System.out.println("Inserisci minuto apertura: ");
				minuto = this.sc.nextInt();
				if(ora >=0 && ora <=23 && minuto >= 0 && minuto <=59)
					ok = true;
				else
					throw new NoSuchElementException();
			}
			catch(NoSuchElementException e) {
				System.out.println("Formato non valido");
			}
		}
		return LocalTime.of(ora, minuto);
	}

	/**
	 * Metodo che permette l'inserimento dell'orario di chiusura per la prenotazione
	 * @return LocalTime(ora,minuto)
	 */
	private LocalTime inserisciChiusura() {
		int ora = 0;
		int minuto = 0;
		boolean ok = false;
		while(!ok)
		{
			try {
				System.out.println("Inserisci ora chiusura: ");
				ora = this.sc.nextInt();
				System.out.println("Inserisci minuto chiusura: ");
				minuto = this.sc.nextInt();
				if(ora >=0 && ora <=23 && minuto >= 0 && minuto <=59)
					ok = true;
				else
					throw new NoSuchElementException();
			}
			catch(NoSuchElementException e) {
				System.out.println("Formato non valido");
			}
		}
		return LocalTime.of(ora, minuto);
	}

	/**
	 * Metodo che permette l'inserimento del Docente
	 * @return Docente d
	 */
	private Docente inserisciDocente() {
		String nome;
		String cognome;
		String matricola;
		nome = this.inserireNomeDocente();
		cognome = this.inserireCognomeDocente();
		matricola = this.inserireMatricola();
		for(Docente d: this.modello.getDocenti())
		{
			if(d.getNome().equals(nome) && d.getCognome().equals(cognome) && d.getMatricola().equals(matricola))
				return d;
		}
		return null;
	}

	/**
	 * Metodo che permette di visualizzare la lista di docenti
	 */
	private void visualizzaDocenti() {
		if(this.modello.getDocenti().isEmpty())
			this.modello.listaDocentiVuota();
		else
		{
			for(Docente d : this.modello.getDocenti())
				System.out.println(d.toString());
		}
	}

}