package Classes;
import java.util.List;
import enumType.DotazioneAula;
/**
 * Classe che definisce le caratteristiche di un'aula
 * @author Daniele Porcelli 20039368
 */
public class AulaSemplice extends Aula {
	/**
	 * Costruttore della classe AulaSemplice senza parametri
	 */
	public AulaSemplice() {
		super();
	}
	/**
	 * Costruttore della classe AulaSemplice
	 * @param String nome
	 * @param Integer capienza
	 * @param DotazioneAula dotazione
	 */
	public AulaSemplice(String nome, Integer capienza, DotazioneAula dotazione) {
		super(nome, capienza);
		if(dotazioni.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
		{
			this.dotazioni.add(dotazione);
		}
	}
	/**
	 * Costruttore della classe AulaSemplice con lista di dotazioni
	 * @param String nome
	 * @param Integer capienza
	 * @param List<DotazioneAula> dotazioni
	 */
	public AulaSemplice(String nome, Integer capienza, List<DotazioneAula> dotazioni) {
		super(nome, capienza);
		this.dotazioni.addAll(dotazioni);
	}
	/**
	 * Metodo che aggiunge una DotazioneAula
	 * @param dotazione
	 */
	public void aggiungiDotazione(DotazioneAula dotazione) {
		if(dotazioni.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioni.add(dotazione);
	}
	/**
	 * Metodo che aggiunge una lista di dotazioni
	 * @param dotazioni
	 */
	public void aggiungiDotazioni(List<DotazioneAula> dotazioni) {
		this.dotazioni.addAll(dotazioni);
	}
	//Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return " AulaSemplice" + super.toString();
	}
}