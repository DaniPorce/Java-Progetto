package Classes;

import java.util.Objects;
/**
 * Classe che definisce le caratteristiche di un docente
 * @author Daniele Porcelli 20039368
 */
public class Docente {
	/**
	 * String nome
	 * String cognome
	 * String matricola
	 */
	private String nome;
	private String cognome;
	private String matricola;
	/**
	 * Costruttore della classe Docente senza parametri
	 */
	public Docente() {
		this.nome = null;
		this.cognome = null;
		this.matricola = null;
	}
	/**
	 * Costruttore della classe Docente
	 * @param String nome
	 * @param String cognome
	 * @param String matricola
	 */
	public Docente(String nome, String cognome, String matricola) {

		this.nome = nome;
		this.cognome = cognome;
		if(matricola.length() != 8)
			throw new IllegalArgumentException("Matricola non valida");
		else
			this.matricola = matricola;
	}
	/**
	 * Metodo che ritorna nome del docente
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * Metodo che imposta il nome del docente
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * Metodo che ritorna il cognome del docente
	 * @return cognome
	 */
	public String getCognome() {
		return cognome;
	}
	/**
	 * Metodo che imposta il cognome del docente
	 * @param cognome
	 */
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	/**
	 * Metodo che ritorna la matricola del docente
	 * @return matricola
	 */
	public String getMatricola() {
		return matricola;
	}
	/**
	 * Metodo che imposta la matricola del docente
	 * @param matricola
	 */
	public void setMatricola(String matricola) {

		this.matricola = matricola;
	}
	//Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return "Docente [nome=" + nome + ", cognome=" + cognome + ", matricola=" + matricola +"]";
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Docente)) {
			return false;
		}
		Docente other = (Docente) obj;
		return Objects.equals(cognome, other.cognome) && Objects.equals(matricola, other.matricola)
				&& Objects.equals(nome, other.nome);
	}
}
