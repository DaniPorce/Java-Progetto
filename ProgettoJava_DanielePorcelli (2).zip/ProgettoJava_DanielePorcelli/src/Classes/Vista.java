package Classes;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.List;
import java.util.Scanner;
/**
 * Classe che definisce l'interfaccia utente
 * @author Daniele Porcelli 20039368
 */
public class Vista implements PropertyChangeListener{

	/**
	 * Scanner sc
	 * String[] mainMenu
	 */
	private Scanner sc;
	private final String[] mainMenu = {"""

			0 - Aggiungi Aula
			1 - Aggiungi Docente
			2 - Prenota Aula
			3 - Cerca Aula (nome,capienza)
			4 - Cerca Docente (nome,cognome,matricola)
			5 - Elimina Aula (nome,capienza)
			6 - Elimina Docente(nome,cognome,matricola)
			7 - Elimina Prenotazione 
			8 - Visualizza Prenotazioni
			9 - Visualizza Aule
			10 - Visualizza Docenti
			11 - Crea Report Aula (nome,data)
			12 - Crea Report Docente (nome,data)
			13 - Chiudi Applicazione """};
	/**
	 * Costruttore delle classe Vista
	 */
	public Vista() {

	}
	public void propertyChange(PropertyChangeEvent evt) {

		if(evt.getPropertyName().equals("AulaSempliceAggiunta")){
			AulaSemplice aula = (AulaSemplice) evt.getNewValue();
			this.AulaSempliceAggiunta(aula);
		}

		if(evt.getPropertyName().equals("AulaSempliceGi�Presente")) {
			AulaSemplice aula = (AulaSemplice) evt.getNewValue();
			this.AulaSempliceGi�Presente(aula);
		}

		if(evt.getPropertyName().equals("AulaChimicaAggiunta")){
			AulaChimica aula = (AulaChimica) evt.getNewValue();
			this.AulaChimicaAggiunta(aula);
		}

		if(evt.getPropertyName().equals("AulaChimicaGi�Presente")) {
			AulaChimica aula = (AulaChimica) evt.getNewValue();
			this.AulaChimicaGi�Presente(aula);
		}

		if(evt.getPropertyName().equals("AulaInformaticaAggiunta")){
			AulaInformatica aula = (AulaInformatica) evt.getNewValue();
			this.AulaInformaticaAggiunta(aula);
		}
		
		
		if(evt.getPropertyName().equals("TipoNonValido")){
			this.TipoNonValido();
		}
		
		
		if(evt.getPropertyName().equals("ListaAuleVuota")){
			this.ListaAuleVuota();
		}
		
		if(evt.getPropertyName().equals("ListaDocentiVuota")){
			this.ListaDocentiVuota();
		}
		
		if(evt.getPropertyName().equals("DocenteNonEliminato")){
			this.DocenteNonEliminato();
		}
		
		if(evt.getPropertyName().equals("ListaPrenotazioneVuota")){
			this.ListaPrenotazioneVuota();
		}
		
		if(evt.getPropertyName().equals("AulainformaticaGi�Presente")) {
			AulaInformatica aula = (AulaInformatica) evt.getNewValue();
			this.AulaInformaticaGi�Presente(aula);
		}

		if(evt.getPropertyName().equals("DocenteAggiunto")) {
			Docente d = (Docente) evt.getNewValue();
			this.DocenteAggiunto(d);
		}
		
		if(evt.getPropertyName().equals("DocenteGi�Presente")) {
			Docente d = (Docente) evt.getNewValue();
			this.DocenteGi�Presente(d);
		}
		if(evt.getPropertyName().equals("AulaTrovata"))
		{
			Aula a = (Aula) evt.getNewValue();
			this.AulaTrovata(a);
		}
		
		if(evt.getPropertyName().equals("DocenteTrovato")) {
			Docente d = (Docente) evt.getNewValue();
			this.DocenteTrovato(d);
		}
		if(evt.getPropertyName().equals("AulaNonTrovata"))
		{
			this.AulaNonTrovata();
		}
		if(evt.getPropertyName().equals("DocenteNonTrovato")) {
			this.DocenteNonTrovato();
		}
		if(evt.getPropertyName().equals("PrenotazioneTrovata")) {
			Prenotazione p = (Prenotazione) evt.getNewValue();
			this.PrenotazioneTrovata(p);
		}
		if(evt.getPropertyName().equals("AulaEliminata")) {
			Aula a = (Aula) evt.getNewValue();
			this.AulaEliminata(a);
		}
		if(evt.getPropertyName().equals("AulaNonEliminata")) {
			this.AulaNonEliminata();
		}
		if(evt.getPropertyName().equals("DocenteEliminato")) {
			String matricola = (String) evt.getOldValue();
			Docente d = (Docente) evt.getNewValue();
			this.DocenteEliminato(matricola, d);
		}
		if(evt.getPropertyName().equals("PrenotazioneEliminata")) {
			Prenotazione p = (Prenotazione) evt.getNewValue();
			this.PrenotazioneEliminata(p);
		}
		if(evt.getPropertyName().equals("PrenotazioneGi�Presente")) {
			Prenotazione p = (Prenotazione) evt.getNewValue();
			this.PrenotazioneGi�Presente(p);
		}
		if(evt.getPropertyName().equals("PrenotazioneAggiunta")) {
			Prenotazione p = (Prenotazione) evt.getNewValue();
			this.PrenotazioneAggiunta(p);
		}
		if(evt.getPropertyName().equals("PrenotazioneNonAggiunta")) {
			this.PrenotazioneNonAggiunta();
		}
		if(evt.getPropertyName().equals("ReportAulaStampato")) {
			@SuppressWarnings("unchecked")
			List<Prenotazione> lista = (List<Prenotazione>) evt.getNewValue();
			this.stampaReportAula(lista);
		}
		if(evt.getPropertyName().equals("ReportDocenteStampato")) {
			@SuppressWarnings("unchecked")
			List<Prenotazione> lista = (List<Prenotazione>) evt.getNewValue();
			this.stampaReportDocente(lista);
		}
		if(evt.getPropertyName().equals("caricamentoAuleSuFileCorretto")) {
			this.caricamentoAuleSuFileCorretto((File) evt.getNewValue());
		}
		if(evt.getPropertyName().equals("ErroreCaricamentoAulesuFile")) {
			this.ErroreCaricamentoAulesuFile((File) evt.getOldValue());
		}
		if(evt.getPropertyName().equals("caricamentoPrenotazioniSuFileCorretto")) {
			this.caricamentoPrenotazioniSuFileCorretto((File) evt.getNewValue());
		}
		if(evt.getPropertyName().equals("ErroreCaricamentoPrenotazionisuFile")) {
			this.ErroreCaricamentoPrenotazionisuFile((File) evt.getOldValue());
		}
		if(evt.getPropertyName().equals("caricamentoDocentiSuFileCorretto")) {
			this.caricamentoDocentiSuFileCorretto((File) evt.getNewValue());
		}
		if(evt.getPropertyName().equals("ErroreCaricamentoDocentisuFile")) {
			this.ErroreCaricamentoDocentisuFile((File) evt.getOldValue());
		}
	}

	/**
	 * Metodo che aggiunge AulaSemplice
	 * @param aula
	 */
	private void AulaSempliceAggiunta(AulaSemplice aula) {
		System.out.println(aula.toString() + "� stato inserito correttamente");
	}
	/**
	 * Metodo che aggiunge AulaChimica
	 * @param aula
	 */
	private void AulaChimicaAggiunta(AulaChimica aula) {
		System.out.println(aula.toString() + "� stato inserito correttamente");
	}
	/**
	 * Metodo che aggiunge AulaChimica
	 * @param aula
	 */
	private void AulaInformaticaAggiunta(AulaInformatica aula) {
		System.out.println(aula.toString() + "� stato inserito correttamente");
	}
	/**
	 * Metodo che avverte che l 'AulaSemplice � gi� presente
	 * @param aula
	 */
	private void AulaSempliceGi�Presente(AulaSemplice aula) {
		System.out.println(aula.toString() + "non � stato inserito poich� � gi� presente nella lista aule");
	}
	/**
	 * Metodo che avverte che l 'AulaChimica � gi� presente
	 * @param aula
	 */
	private void AulaChimicaGi�Presente(AulaChimica aula) {
		System.out.println(aula.toString() + "non � stato inserito poich� � gi� presente nella lista aule");
	}
	/**
	 *  Metodo che avverte che l 'AulaInformatica � gi� presente
	 * @param aula
	 */
	private void AulaInformaticaGi�Presente(AulaInformatica aula) {
		System.out.println(aula.toString() + "non � stato inserito poich� � gi� presente nella lista aule");
	}
	/**
	 * Metodo per stampare il corretto inserimento del docente
	 * @param d
	 */
	private void DocenteAggiunto(Docente d) {
		System.out.println(d.toString() + "� stato inserito correttamente");
	}
	
	/**
	 * Metodo per stampare che il docente � gi� presente nella lista docenti
	 * @param d
	 */
	private void DocenteGi�Presente(Docente d) {
		System.out.println(d.toString() + "non � stato inserito poich� � gi� presente nella lista docenti");
	}

	/**
	 * Metodo per stampare la verifica se l'aula � stata trovata
	 * @param aula
	 */
	private void AulaTrovata(Aula aula)
	{
		if(aula != null)
			System.out.println(aula.toString() + "� stata trovata");
		else
			System.out.println("Non � stata trovata nessuna aula.\n");
	}

	/**
	 * Metodo per stampare la verifica se l'aula non � stata trovata
	 * @param aula
	 */
	private void AulaNonTrovata()
	{
		System.out.println("L'aula cercata non corrisponde a quella presente nella lista aule");
	}
	
	/**
	 * Metodo per stampare la verifica del tipo se non � valido
	 */
	private void TipoNonValido()
	{
		System.out.println("Il Tipo di aula scelto non � valido");
	}

	/**
	 * Metodo per stampare la verifica se il docente � stato trovato
	 * @param docente
	 */
	private void DocenteTrovato(Docente docente)
	{
		if(docente != null)
			System.out.println(docente.toString() + "� stato trovato");
	}
	
	/**
	 * Metodo che stampa la verifica se la lista aule � vuota
	 */
	private void ListaAuleVuota()
	{
		System.out.println("La lista aule � vuota");
	}
	
	/**
	 * Metodo che stampa la verifica se la lista docenti � vuota
	 */
	private void ListaDocentiVuota()
	{
		System.out.println("La lista docenti � vuota");
	}
	
	/**
	 * Metodo che stampa che il docente non � stato eliminato
	 */
	private void DocenteNonEliminato()
	{
		System.out.println("Il Docente non � stato eliminato");
	}
	
	/**
	 * Metodo che stampa la verifica se la lista prenotazioni � vuota
	 */
	private void ListaPrenotazioneVuota() 
	{
		System.out.println("La lista prenotazione � vuota");
	}

	/**
	 * Metodo per stampare la verifica se il docente non � stato trovato
	 * @param docente
	 */
	private void DocenteNonTrovato()
	{
		System.out.println("Il docente cercato non corrisponde a quello presente nella lista docenti");
	}

	/**
	 * Metodo per stampare la verifica se la prenotazione � stata trovata
	 * @param p
	 */
	private void PrenotazioneTrovata(Prenotazione p)
	{
		if(p != null)
			System.out.println(p.toString() + "� stata trovata");
		else
			System.out.println("Non � stata trovata nessuna prenotazione");
	}

	/**
	 * Metodo per stampare la verifica se l'aula � stata eliminata
	 * @param aula
	 */
	private void AulaEliminata(Aula aula)
	{
		if(aula != null)
			System.out.println(aula.toString() + "� stata eliminata");
		else
			System.out.println("Non � stata eliminata nessuna Aula");
	}
	
	/**
	 * Metodo per stampare la verifica se l'aula non � stata eliminata
	 * @param aula
	 */
	private void AulaNonEliminata()
	{
		System.out.println("Aula selezionata non � stata cancellata");
	}

	/**
	 * Metodo per stampare la verifica se il docente � stato eliminato
	 * @param matricola
	 * @param doc
	 */
	private void DocenteEliminato(String matricola,Docente doc)
	{
		if(matricola != null)
			System.out.println(doc.toString() + "� stato rimosso");
		else
			System.out.println("Il docente con matricola " + matricola + "non � stato rimosso");
	}
	
	/**
	 * Metodo per stampare la verifica se la prenotazione � stata eliminata
	 * @param p
	 */
	private void PrenotazioneEliminata(Prenotazione p)
	{
		if(p != null)
			System.out.println(p.toString() + " � stato rimosso");
		else
			System.out.println("La prenotazione non � stata rimossa");
	}
	
	/**
	 * Metodo per stampare la verifica se la prenotazione � gi� presente
	 * @param p
	 */
	private void PrenotazioneGi�Presente(Prenotazione p)
	{
		System.out.println(p.toString() + "� gi� presente nella lista\n");
	}

	/**
	 * Metodo per stampare la verifica se la prenotazione � stata aggiunta alla lista
	 * @param p
	 */
	private void PrenotazioneAggiunta(Prenotazione p)
	{
		System.out.println(p.toString() + "� stata aggiunta correttamente\n");
	}
	
	/**
	 * Metodo per stampare la verifica se la prenotazione non � stata aggiunta alla lista
	 * @param p
	 */
	private void PrenotazioneNonAggiunta()
	{
		System.out.println("La prenotazione non � stata aggiunta correttamente");
	}

	/**
	 * Metodo per stampare la verifica se il Reportdocente � stato visualizzato
	 * @param lista
	 */

	private void stampaReportDocente(List<Prenotazione> lista)
	{
		if(!lista.isEmpty())
			System.out.println("Il ReportDocente � stato visualizzato correttamente");
		else
			System.out.println("Il ReportDocente non � stato visualizzato");
	}

	/**
	 * Metodo per stampare la verifica se il ReportAula � stato visualizzato
	 * @param lista
	 */

	private void stampaReportAula(List<Prenotazione> lista)
	{
		if(!lista.isEmpty())
			System.out.println("Il ReportAula � stato visualizzato correttamente");
		else
			System.out.println("Il ReportAula non � stato visualizzato");
	}

	/**
	 * Metodo per stampare l'errore di caricamento dei dati delle aule nel file
	 * @param filename
	 */
	private void ErroreCaricamentoAulesuFile(File filename) {
		System.out.println("Errore nel caricamento dei dati delle aule nel file "+filename.getName());
	}

	/**
	 * Metodo per stampare il corretto caricamento dei dati delle aule nel file
	 * @param filename
	 */
	private void caricamentoAuleSuFileCorretto(File filename) {
		System.out.println("Caricamento corretto dei dati delle aule nel file "+filename.getName());
	}

	/**
	 * Metodo per stampare l'errore di caricamento dei dati delle prenotazioni nel file
	 * @param filename
	 */
	private void ErroreCaricamentoPrenotazionisuFile(File filename) {
		System.out.println("Errore nel caricamento dei dati delle prenotazioni nel file "+filename.getName());
	}

	/**
	 * Metodo per stampare il corretto caricamento dei dati delle prenotazioni nel file
	 * @param filename
	 */
	private void caricamentoPrenotazioniSuFileCorretto(File filename) {
		System.out.println("Caricamento corretto dei dati delle prenotazioni nel file "+filename.getName());
	}

	/**
	 * Metodo per stampare l'errore di caricamento dei dati dei docenti nel file
	 * @param filename
	 */
	private void ErroreCaricamentoDocentisuFile(File filename) {
		System.out.println("Errore nel caricamento dei dati dei docenti nel file "+filename.getName());
	}

	/**
	 *  Metodo per stampare l'errore di caricamento dei dati dei docenti nel file
	 * @param filename
	 */
	private void caricamentoDocentiSuFileCorretto(File filename) {
		System.out.println("Caricamento corretto dei dati dei docenti nel file "+filename.getName());
	}
	
	/**
	 * Metodo per stampare Avvio sistema di gestione Aule
	 */
	protected void startingApp() {
		System.out.println("Avvio sistema di gestione Aule");
	}

	/**
	 * Metodo per stampare Arrivederci
	 */
	protected void closeApp() {
		System.out.println("Arrivederci");
	}

	/**
	 * Metodo per stampare Menu
	 * @return value
	 */
	protected int displayMenu() {
		for(String s : mainMenu) {
			System.out.println(s);
		}
		int value = 0;
		try {
			sc = new Scanner(System.in);
			value = sc.nextInt();
			if (value < 0 || value > 13) {
				throw new IllegalArgumentException();
			}
		}
		catch (IllegalArgumentException e) {
			while(value < 0 || value > 13) {
				System.err.println("Errore, inserire un numero compreso tra 0 e 13:");
				value = sc.nextInt();
			}
			return value;
		}
		return value;
	}
}
