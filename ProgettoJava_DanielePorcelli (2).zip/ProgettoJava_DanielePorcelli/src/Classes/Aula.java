package Classes;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;

import enumType.DotazioneAula;
/**
 * Classe che definisce le caratteristiche di un'aula
 * 
 * @author Daniele Porcelli 20039368
 */
public abstract class Aula {
	/**
	 * String nome Integer capienza 
	 * Set<Prenotazione> prenotazioni
	 * List<DotazioneAula> dotazioni
	 */
	private String nome;
	private Integer capienza;
	private Set<Prenotazione> prenotazioni;
	protected List<DotazioneAula> dotazioni;
	/**
	 * Costruttore della classe Aula senza parametri
	 */
	public Aula() {
		this.nome = null;
		this.capienza = 0;
		prenotazioni = new HashSet<Prenotazione>();
		dotazioni = new ArrayList<DotazioneAula>();
		dotazioni.add(DotazioneAula.lavagna);
		dotazioni.add(DotazioneAula.Proiettore);
	}
	/**
	 * Costruttore della classe Aula
	 * @param String  nome
	 * @param Integer capienza
	 */
	public Aula(String nome, Integer capienza) {
		this.nome = nome;
		this.setCapienza(capienza);
		prenotazioni = new HashSet<Prenotazione>();
		dotazioni = new ArrayList<DotazioneAula>();
		dotazioni.add(DotazioneAula.lavagna);
		dotazioni.add(DotazioneAula.Proiettore);
	}
	/**
	 * Metodo che ritorna il nome dell'aula
	 * @return nome
	 */
	protected String getNome() {
		return nome;
	}
	/**
	 * Metodo che imposta il nome dell'aula
	 * @param nome
	 */
	protected void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * Metodo che ritorna la capienza dell'aula
	 * @return capienza
	 */
	protected Integer getCapienza() {
		return capienza;
	}
	/**
	 * Metodo che imposta la capienza dell'aula
	 * @param capienza
	 */
	protected void setCapienza(Integer capienza) {
		if (capienza > 0)
			this.capienza = capienza;
		else
			throw new IllegalArgumentException("Capienza non possibile");
	}
	/**
	 * Metodo che ritorna la lista di dotazioni
	 * @return dotazioni
	 */
	protected List<DotazioneAula> getDotazioni() {
		return dotazioni;
	}
	/**
	 * Metodo che imposta la lista di dotazioni
	 * @param dotazioni
	 */
	protected void setDotazioni(List<DotazioneAula> dotazioni) {
		this.dotazioni = dotazioni;
	}
	/**
	 * Metodo che ritorna la lista di prenotazioni
	 * @return prenotazioni
	 */
	protected Set<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}
	/**
	 * Metodo che imposta la lista di prenotazioni
	 * @param prenotazioni
	 */
	protected void setPrenotazioni(Set<Prenotazione> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}
	// Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return " [nome=" + nome + ", capienza=" + capienza + ", prenotazioni=" + prenotazioni + " dotazioni="
				+ dotazioni;
	}
	/**
	 * Metoo che consente di prenotare l'aula
	 * @param e
	 */
	protected void Prenota(Prenotazione e) {
		boolean trovato = false;
		for (Prenotazione pr : this.getPrenotazioni()) {
			if (pr.getData().equals(e.getData()) && pr.getApertura().equals(e.getApertura())
					&& pr.getChiusura().equals(e.getChiusura()) && pr.getDocente().equals(e.getDocente())) {
				System.out.println("PrenotazioneGi�Aggiunta");
				trovato = true;
			}
		}

		if (this.getPrenotazioni().isEmpty()) {
			this.getPrenotazioni().add(e);
			trovato = true;
		}

		if (!trovato) {
			for (Prenotazione pr : this.getPrenotazioni()) {
				if (pr.getData().equals(e.getData())) {
					if (e.getApertura().getHour() < pr.getApertura().getHour()
							&& e.getChiusura().getHour() < pr.getApertura().getHour()
							|| e.getApertura().getHour() > pr.getChiusura().getHour()
							&& e.getChiusura().getHour() > pr.getChiusura().getHour()) {
						this.getPrenotazioni().add(e);
					} else
						throw new IllegalArgumentException("Non � possibile effettuare la prenotazione");
				} else
					this.getPrenotazioni().add(e);
			}
		}
	}
	/**
	 * Metodo che permette di visualizzare le aula per una data e orario definiti
	 * @param data
	 * @param apertura
	 * @param chiusura
	 */
	public void visualizzaAulaData(LocalDate data,LocalTime apertura,LocalTime chiusura)
	{

		for(Prenotazione p: this.getPrenotazioni())
		{
			if(p.getData().equals(data) && p.getApertura().equals(apertura) && p.getChiusura().equals(chiusura))
			{
				System.out.println(this.toString());
				break;
			}
			else
				throw new NoSuchElementException("Non � presente questa aula");
		}
	}
	/**
	 * Metodo che permette di visualizzare le aule per nome_aula e capienza definiti
	 * @param nome_aula
	 * @param capienza
	 */
	public void visualizzaAulaNomeCapienza(String nome_aula,Integer capienza) {

		if(nome_aula == null || capienza == null)
			throw new NullPointerException("Uno dei campi � null");

		if(this.getNome().equals(nome_aula) && this.getCapienza().equals(capienza))
			System.out.println(this.toString());
		else
			throw new NoSuchElementException("Non � presente nessuna aula con requisti richiesti");
	}
	/**
	 * Metodo che permette di visualizzare se la dotazione � presente nella listaDotazioni
	 * @param strumento
	 */
	public void visualizzaAulaDotazione(DotazioneAula strumento){

		for(DotazioneAula dot: this.getDotazioni())
		{
			if(dot.equals(strumento))
				System.out.println(this.toString());
			else
				throw new NoSuchElementException("Non � presente nessuna aula con dotazione richiesta");
		}
	}
	/**
	 * Metodo che restituisce un metodo di ordinamento  
	 * @return comp
	 */
	public Comparator<Prenotazione> richiama()
	{
		Comparator<Prenotazione> comp = new Comparator<Prenotazione>()
		{
			public int compare(Prenotazione o1, Prenotazione o2) {
				return o1.getApertura().getHour() - o2.getApertura().getHour();
			}

		};
		return comp;
	}
	/**
	 * Classe che definisce le caratteristiche di Report
	 */
	public class Report {

		/**
		 * List<Prenotazione> report
		 * List<Aula> lista
		 * List<String> nome
		 */
		private List<Prenotazione> report;
		private List<Aula> lista;
		private List<String> nome;
		/**
		 * Costruttrore dela classe locale Report
		 * @param aula
		 */
		public Report(Aula aula) {
			report = new ArrayList<>();
			lista = new ArrayList<>();
			nome = new ArrayList<>();
			lista.add(aula);
		}
		/**
		 * Costruttrore dela classe locale Report con lista di aule
		 * @param aula
		 */
		public Report(List<Aula> aula) {
			report = new ArrayList<>();
			lista = new ArrayList<>();
			nome = new ArrayList<>();
			lista.addAll(aula);
		}
		/**
		 * Metodo che ritorna un ArrayList contenente tutti i report
		 * @return ArrayList contenente tutti i report
		 */
		public List<Prenotazione> getReport() {
			return this.report;
		}
		/**
		 * Metodo che ritorna un ArrayList contenente la lista di aule
		 * @return
		 */
		public List<Aula> getAula() {
			return this.lista;
		}
		/**
		 * Metodo che permette di visualizzare Report Aula
		 * @param nome_aula
		 * @param data
		 */
		public void creaReportAula(String nome_aula,LocalDate data) 
		{
			if(nome_aula == null || data == null) 
				throw new NullPointerException("Uno dei due campi � null"); 
			else { 
				for(Aula aula : lista)
				{
					if(aula.getNome().equals(nome_aula))
					{
						for(Prenotazione p: aula.getPrenotazioni())
						{
							if(p.getData().equals(data))
								report.add(p);
						}
					}
				}
			}
			Collections.sort(report, richiama()); 
			for(Prenotazione p: report)
				System.out.println(p); 
		}
		/**
		 * Metodo che permette di visualizzare il Report Docente
		 * @param data
		 * @param docente
		 */
		public void creaReportDocente(LocalDate data,Docente docente) 
		{
			if( data == null || docente == null)
				throw new NullPointerException("Uno dei campi � null");
			else
			{
				for(Aula aula: lista)
				{
					nome.add(aula.getNome());
					for(Prenotazione p : aula.getPrenotazioni())
					{
						if (p.getData().equals(data) && p.getDocente().equals(docente))
							report.add(p);
					}

				}
			}
			Collections.sort(report,richiama());
			for(Prenotazione p : report)
			{
				System.out.println(p.toString());
				System.out.println(nome);
			}
		}
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Aula)) {
			return false;
		}
		Aula other = (Aula) obj;
		return Objects.equals(capienza, other.capienza) && Objects.equals(dotazioni, other.dotazioni)
				&& Objects.equals(nome, other.nome) && Objects.equals(prenotazioni, other.prenotazioni);
	}
}

