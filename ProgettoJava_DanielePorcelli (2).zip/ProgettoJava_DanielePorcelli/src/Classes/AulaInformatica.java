package Classes;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import enumType.DotazioneAula;
import enumType.DotazioneInformatica;
/**
 * Classe che definisce le caratteristiche di un'AulaInformatica
 * @author Daniele Porcelli 20039368
 */
public class AulaInformatica extends Aula {
	/**
	 * List<DotazioneInformatica> dotazioniInformatica
	 */
	private List<DotazioneInformatica> dotazioniInformatica = new ArrayList<DotazioneInformatica>();
	/**
	 * Costruttore dell'AulaInformatica senza parametri
	 */
	public AulaInformatica() {
		super();
	}
	/**
	 * Costruttore della classe AulaInformatica
	 * @param String nome
	 * @param Integer capienza
	 * @param DotazioneInformatica dotazione
	 */
	public AulaInformatica(String nome, Integer capienza, DotazioneInformatica dotazione) {
		super(nome, capienza);
		if(dotazioniInformatica.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioniInformatica.add(dotazione);
	}
	/**
	 * Costruttore della classe AulaInformatica con lista di dotazioni
	 * @param nome
	 * @param capienza
	 * @param dotazioni
	 */
	public AulaInformatica(String nome, int capienza, List<DotazioneInformatica> dotazioni) {
		super(nome, capienza);
		this.dotazioniInformatica.addAll(dotazioni);
	}
	/**
	 * Metodo che aggiunge una DotazioneAula
	 * @param dotazione
	 */
	public void aggiungiDotazione(DotazioneAula dotazione) {
		if(dotazioni.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioni.add(dotazione);
	}
	/**
	 * Metodo che aggiunge una Dotazioneinformatica
	 * @param dotazione
	 */
	public void aggiungiDotazioneInformatica(DotazioneInformatica dotazione) {
		if(dotazioniInformatica.contains(dotazione))
			throw new IllegalArgumentException("Dotazione gi� presente");
		else
			this.dotazioniInformatica.add(dotazione);
	}
	/**
	 * Metodo che aggiunge una lista di dotazioni
	 * @param dotazioni
	 */
	public void aggiungiDotazioni(List<DotazioneAula> dotazioni) {
		this.dotazioni.addAll(dotazioni);
	}
	/**
	 * Metodo che aggiunge una lista di dotazioniInformatica
	 * @param dotazioni
	 */
	public void aggiungiDotazioniInformatica(List<DotazioneInformatica> dotazioni) {
		this.dotazioniInformatica.addAll(dotazioni);
	}
	/**
	 * Metodo che ritorna lista DotazioniInformatica
	 * @return dotazioniInformatica
	 */
	public List<DotazioneInformatica> getDotazioniInformatica() {
		return dotazioniInformatica;
	}
	/**
	 * Metodo che imposta lista DotazioniInformatica
	 * @param dotazioniInformatica
	 */
	public void setDotazioniInformatica(List<DotazioneInformatica> dotazioniInformatica) {
		this.dotazioniInformatica = dotazioniInformatica;
	}
	/**
	 * Metodo che permette di visualizzare se la dotazione � presente nella listaDotazioniInformatica
	 * @param strumento
	 */
	public void visualizzaAulaDotazioneInformatica(DotazioneInformatica strumento){

		for(DotazioneInformatica dot: this.getDotazioniInformatica())
		{
			if(dot.equals(strumento))
				System.out.println(this.toString());
			else
				throw new NoSuchElementException("Non � presente nessuna aula con dotazione richiesta");
		}
	}
	//Metodo che ritorna i valori contenuti dagli attributi dell'oggetto
	public String toString() {
		return " AulaInformatica [dotazioniInformatica=" + dotazioniInformatica + super.toString();
	}
}