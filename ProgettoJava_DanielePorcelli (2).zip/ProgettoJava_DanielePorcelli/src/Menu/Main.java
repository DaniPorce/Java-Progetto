package Menu;
import Classes.Modello;
import Classes.Vista;
import Classes.Controller;
/**
 * Costruttore che invoca il Main per il funzionamento del programma
 * @author Daniele Porcelli 20039368
 *
 */
public class Main{
	public static void main(String[] args) {
		Vista vista = new Vista();
		Modello modello = new Modello();
		Controller controller = new Controller(vista,modello);
		modello.addPropertyChangeListener(vista);
		controller.avvioCartella();
	}
}
