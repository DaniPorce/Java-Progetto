package enumType;

/**
 * Classe che definisce i valori della DotazioneSemplice
 * @author Daniele Porcelli 20039368
 */

public enum DotazioneAula {
	/**
	 * Lavagna
	 */
	lavagna,
	/**
	 * Proiettore
	 */
	Proiettore,
	/**
	 * Tablet
	 */
	Tablet,
	/**
	 * Lim
	 */
	Lim
}