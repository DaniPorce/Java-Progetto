package enumType;

/**
 * Classe che definisce i valori della DotazioneChimica
 * @author Daniele Porcelli 20039368
 */

public enum DotazioneChimica {
	/**
	 * Camice
	 */
	Camice,
	/**
	 * Laboratorio
	 */
	Laboratorio,
	 /**
	  * Tablet
	  */
	Tablet,
	/**
	 * Lim
	 */
	Lim,
	/**
	 * Bilancia
	 */
	Bilancia,
	/**
	 * Termometro
	 */
	Termomentro
}