package enumType;

/**
 * Classe che definisce i valori della DotazioneInformatica
 * @author Daniele Porcelli 20039368
 */
public enum DotazioneInformatica {
	/**
	 * Tablet
	 */
	Tablet,
	/**
	 * Lim
	 */
	Lim,
	/**
	 * Computer
	 */
	Computer
}